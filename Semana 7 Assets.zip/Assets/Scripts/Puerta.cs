using UnityEngine;

/// <summary>
/// Hereda de ObjetoInteractivo. Representa una puerta que puede abrirse y cerrarse.
/// </summary>
public class Puerta : ObjetoInteractivo
{
    private bool estaAbierta = false;

    public override void Interactuar()
    {
        // Reutiliza la verificación de la clase base (refactorización)
        if (!PuedeInteractuar()) return;

        estaAbierta = !estaAbierta;
        string estado = estaAbierta ? "abre" : "cierra";
        Debug.Log($"La {NombreObjeto} se {estado}.");

        // Aquí puedes agregar animación: GetComponent<Animator>().SetBool("Abierta", estaAbierta);
    }
}
