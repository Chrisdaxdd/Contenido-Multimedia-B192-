using UnityEngine;

/// <summary>
/// Hereda de ObjetoInteractivo. Representa un cofre que puede abrirse una sola vez.
/// </summary>
public class Cofre : ObjetoInteractivo
{
    [Header("Cofre")]
    [SerializeField] private string contenido = "Espada legendaria";

    private bool yaAbierto = false;

    public override void Interactuar()
    {
        // Reutiliza la verificación de la clase base (refactorización)
        if (!PuedeInteractuar()) return;

        if (yaAbierto)
        {
            Debug.Log($"El {NombreObjeto} ya está vacío.");
            return;
        }

        yaAbierto = true;
        Debug.Log($"¡Abriste el {NombreObjeto}! Obtuviste: {contenido}");

        // Desactiva el cofre tras usarlo
        SetActivo(false);
    }
}
