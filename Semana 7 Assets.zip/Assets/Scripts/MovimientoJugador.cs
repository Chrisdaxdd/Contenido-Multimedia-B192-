using UnityEngine;

/// <summary>
/// Movimiento básico del jugador con WASD o flechas.
/// Requiere que la Capsule tenga un Rigidbody.
/// </summary>
public class MovimientoJugador : MonoBehaviour
{
    [Header("Movimiento")]
    [SerializeField] private float velocidad = 5f;
    [SerializeField] private float velocidadRotacion = 10f;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        float horizontal = Input.GetAxis("Horizontal"); // A/D o flechas
        float vertical   = Input.GetAxis("Vertical");   // W/S o flechas

        Vector3 direccion = new Vector3(horizontal, 0f, vertical).normalized;

        if (direccion.magnitude > 0.1f)
        {
            // Mover
            Vector3 nuevaPosicion = rb.position + direccion * velocidad * Time.fixedDeltaTime;
            rb.MovePosition(nuevaPosicion);

            // Rotar hacia donde se mueve
            Quaternion rotacionObjetivo = Quaternion.LookRotation(direccion);
            rb.rotation = Quaternion.Slerp(rb.rotation, rotacionObjetivo, velocidadRotacion * Time.fixedDeltaTime);
        }
    }
}
