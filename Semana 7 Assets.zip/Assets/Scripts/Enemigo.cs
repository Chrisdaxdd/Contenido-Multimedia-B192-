using UnityEngine;

/// <summary>
/// Enemigo que detecta colisiones con el jugador y aplica daño.
/// No hereda de ObjetoInteractivo porque no es interactuable directamente,
/// pero interactúa con el Jugador a través del sistema de colisiones de Unity.
/// </summary>
public class Enemigo : MonoBehaviour
{
    [Header("Estadísticas")]
    [SerializeField] private int danio = 10;
    [SerializeField] private int vida = 50;
    [SerializeField] private string nombreEnemigo = "Enemigo";

    public int Vida
    {
        get => vida;
        private set => vida = Mathf.Clamp(value, 0, 999);
    }

    private void OnCollisionEnter(Collision collision)
    {
        Jugador jugador = collision.gameObject.GetComponent<Jugador>();
        if (jugador != null)
        {
            Debug.Log($"{nombreEnemigo} colisiona con el jugador.");
            jugador.RecibirDanio(danio);
        }
    }

    public void RecibirDanio(int cantidad)
    {
        Vida -= cantidad;
        Debug.Log($"{nombreEnemigo} recibe {cantidad} de daño. Vida: {Vida}");

        if (Vida <= 0)
        {
            Debug.Log($"{nombreEnemigo} ha sido derrotado.");
            Destroy(gameObject);
        }
    }
}
