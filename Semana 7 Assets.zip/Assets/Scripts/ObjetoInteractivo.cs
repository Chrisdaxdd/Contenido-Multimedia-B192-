using UnityEngine;

/// <summary>
/// Clase base para todos los objetos con los que el jugador puede interactuar.
/// Aplica encapsulación y sirve como punto de extensión (herencia + polimorfismo).
/// </summary>
public class ObjetoInteractivo : MonoBehaviour
{
    [Header("Configuración")]
    [SerializeField] private string nombreObjeto = "Objeto";
    [SerializeField] private bool estaActivo = true;

    // Propiedad pública de solo lectura (encapsulación)
    public bool EstaActivo => estaActivo;
    public string NombreObjeto => nombreObjeto;

    /// <summary>
    /// Método principal de interacción. Las subclases sobreescriben este método
    /// pero pueden llamar a base.Interactuar() para reutilizar la lógica común.
    /// </summary>
    public virtual void Interactuar()
    {
        if (!estaActivo)
        {
            Debug.Log($"{nombreObjeto} no está disponible para interactuar.");
            return;
        }

        Debug.Log($"Interactuando con: {nombreObjeto}");
    }

    /// <summary>
    /// Método protegido reutilizable: evita duplicar la verificación de estado
    /// en todas las subclases (refactorización de código repetido).
    /// </summary>
    protected bool PuedeInteractuar()
    {
        return estaActivo;
    }

    /// <summary>
    /// Permite activar o desactivar el objeto desde otras clases.
    /// </summary>
    public void SetActivo(bool valor)
    {
        estaActivo = valor;
    }
}
