using UnityEngine;

/// <summary>
/// NPC (Personaje No Jugable). Hereda de ObjetoInteractivo.
/// Demuestra cómo añadir un nuevo tipo de objeto al sistema existente
/// sin modificar las clases base (principio Open/Closed de POO).
/// </summary>
public class NPC : ObjetoInteractivo
{
    [Header("Diálogo")]
    [SerializeField] private string[] dialogos = {
        "¡Hola, viajero! Bienvenido a estas tierras.",
        "Cuentan que en el norte hay un cofre con grandes riquezas...",
        "Cuídate de los enemigos que rondan el bosque.",
        "¡Hasta pronto, aventurero!"
    };

    private int indiceDialogo = 0;

    public override void Interactuar()
    {
        // Reutiliza la verificación de la clase base (refactorización)
        if (!PuedeInteractuar()) return;

        if (dialogos == null || dialogos.Length == 0)
        {
            Debug.Log($"{NombreObjeto} no tiene nada que decir.");
            return;
        }

        Debug.Log($"{NombreObjeto} dice: \"{dialogos[indiceDialogo]}\"");

        // Avanza al siguiente diálogo cíclicamente
        indiceDialogo = (indiceDialogo + 1) % dialogos.Length;
    }
}
