using UnityEngine;

/// <summary>
/// Controla al jugador. Detecta la tecla E y lanza la interacción
/// con el ObjetoInteractivo más cercano dentro del rango.
/// </summary>
public class Jugador : MonoBehaviour
{
    [Header("Interacción")]
    [SerializeField] private float rangoInteraccion = 2f;
    [SerializeField] private LayerMask capaObjetos;

    [Header("Estadísticas")]
    [SerializeField] private int vida = 100;

    public int Vida
    {
        get => vida;
        private set => vida = Mathf.Clamp(value, 0, 100);
    }

    private ObjetoInteractivo objetoCercano;

    void Update()
    {
        BuscarObjetoCercano();

        // ✅ Input clásico (sin Input System)
        if (Input.GetKeyDown(KeyCode.E) && objetoCercano != null)
        {
            objetoCercano.Interactuar();
        }
    }

    /// <summary>
    /// Detecta con un OverlapSphere si hay un ObjetoInteractivo en rango.
    /// </summary>
    private void BuscarObjetoCercano()
    {
        Collider[] colisiones = Physics.OverlapSphere(transform.position, rangoInteraccion, capaObjetos);
        objetoCercano = null;

        foreach (Collider col in colisiones)
        {
            ObjetoInteractivo obj = col.GetComponent<ObjetoInteractivo>();
            if (obj != null && obj.EstaActivo)
            {
                objetoCercano = obj;
                break;
            }
        }
    }

    public void RecibirDanio(int cantidad)
    {
        Vida -= cantidad;
        Debug.Log($"Jugador recibe {cantidad} de daño. Vida restante: {Vida}");

        if (Vida <= 0)
            Debug.Log("El jugador ha muerto.");
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, rangoInteraccion);
    }
}